package eu.kanade.tachiyomi.util.chapter

class NoChaptersException : Exception()

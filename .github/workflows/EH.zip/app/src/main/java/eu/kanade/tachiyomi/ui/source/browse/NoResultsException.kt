package eu.kanade.tachiyomi.ui.source.browse

class NoResultsException : Exception()

package eu.kanade.tachiyomi.ui.base.controller

interface NoToolbarElevationController

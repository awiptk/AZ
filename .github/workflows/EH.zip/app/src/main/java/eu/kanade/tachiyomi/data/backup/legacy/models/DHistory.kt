package eu.kanade.tachiyomi.data.backup.legacy.models

data class DHistory(val url: String, val lastRead: Long)

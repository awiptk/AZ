package eu.kanade.tachiyomi.source.model

data class MangasPage(val mangas: List<SManga>, val hasNextPage: Boolean)

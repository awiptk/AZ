package eu.kanade.tachiyomi.data.track.bangumi

data class Status(
    val id: Int? = 0,
    val name: String? = "",
    val type: String? = ""
)

package eu.kanade.tachiyomi.data.database.models

class MangaChapter(val manga: Manga, val chapter: Chapter)

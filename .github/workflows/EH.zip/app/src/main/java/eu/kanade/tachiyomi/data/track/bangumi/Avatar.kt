package eu.kanade.tachiyomi.data.track.bangumi

data class Avatar(
    val large: String? = "",
    val medium: String? = "",
    val small: String? = ""
)
